create view VIEW_SSCT as
  select stu."STUID",stu."STUNAME",stu."STUAGE",stu."STUSEX",c."COURSEID",c."COURSENAME",c."TEAID",t.teaname,s.score from tblstudent stu, tblscore s,tblcourse c,tblteacher t
 where stu.stuid = s.stuid
 and s.courseid  = c.courseid
 and c.teaid = t.teaid
/

