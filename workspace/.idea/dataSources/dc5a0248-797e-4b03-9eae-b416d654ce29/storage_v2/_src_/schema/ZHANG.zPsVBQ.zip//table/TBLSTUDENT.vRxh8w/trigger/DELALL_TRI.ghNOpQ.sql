create trigger DELALL_TRI
  after delete
  on TBLSTUDENT
  for each row
  begin
  --:old代表删除的数据
  delete from tblscore where stuid = :old.stuid;
  end;
/

