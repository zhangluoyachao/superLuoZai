create procedure  emp_proc(v_name in varchar2,v_sal out emp.sal%type)
as
begin
  update emp set sal = sal+500 where ename =v_name;
  select sal into v_sal from emp where ename=v_name;
end;
/

