create function empcount
return number
as
f_count number;
begin
  select count(1) into f_count from emp;
  return f_count;
  end;
/

