create function emp_getYear(e_id emp.empno%type)
return number
as
eyear number;
begin
  select extract(year from hiredate) into eyear from emp where empno = e_id;
  return eyear;
  end;
/

