create trigger EMP_TIP
  before insert
  on EMP
  for each row
  declare
empid number;
begin
  select max(empno)+1 into empid from emp;
  :new.empno := empid;
  DBMS_OUTPUT.put_line('新增的主键是'||empid);
  end;
/

