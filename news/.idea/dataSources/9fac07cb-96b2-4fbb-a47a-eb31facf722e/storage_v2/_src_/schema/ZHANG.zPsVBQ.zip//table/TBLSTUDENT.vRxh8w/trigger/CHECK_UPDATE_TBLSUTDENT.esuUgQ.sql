create trigger CHECK_UPDATE_TBLSUTDENT
  before update
  on TBLSTUDENT
  for each row
  when (old.stuid = 1001)
  begin
  --  raise_application_error( 错误编号，错误信息 )
  raise_application_error(-20000,'stuid=1001的信息不能删除！');
  end;
/

