create procedure emp_salary(iname in emp.ename%type,osal out emp.sal%type)
as
begin
begin
  select sal  into osal from emp where ename = iname;
  end;
end emp_salary;
/

