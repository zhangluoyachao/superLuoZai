create procedure testtable_pro(v_name in testtable.name%type)
    as
    begin
    declare
    senum number(10);
      begin
    select count(1) into senum from testtable;
    if senum = 0 then
      insert into testtable values(1,v_name);
      else
        select max(id) into senum from testtable;
        insert into testtable values(senum+1,v_name);
      end if;
     commit;
    end;
   end testtable_pro;
/

